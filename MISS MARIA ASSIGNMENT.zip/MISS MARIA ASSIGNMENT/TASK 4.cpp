// Roll No: L1F26BSCS0097
// Name: Sheraz Ahmed

#include <iostream>
using namespace std;

int main() {
    int age;

    cout << "Enter your age: ";
    cin >> age;

    // checking to the voting eligibility
    if (age >= 18) {
        cout << "Eligible to vote." << endl;
    }
    else {
        cout << "Not eligible to vote." << endl;
    }

    return 0;
}
