// Roll No: L1F26BSCS0097
// Name: Sheraz Ahmed

#include <iostream>
using namespace std;

int main() {
    int visitorAge;

    cout << "Enter visitor age: ";
    cin >> visitorAge;

    // checking age categories for ticket price
    if (visitorAge < 0) {
        cout << "Invalid age" << endl;
    }
    else if (visitorAge < 5) {
        cout << "Free entry" << endl;
    }
    else if (visitorAge <= 17) {
        cout << "Child/Student ticket: Rs. 200" << endl;
    }
    else if (visitorAge <= 59) {
        cout << "Adult ticket: Rs. 500" << endl;
    }
    else {
        cout << "Senior ticket: Rs. 300" << endl;
    }

    return 0;
}

/*
Observation:
Conditions are arranged from lowest to highest age so that each age falls into exactly one correct block.
If we put a higher condition first, the younger age groups would get the wrong ticket prices.
*/
