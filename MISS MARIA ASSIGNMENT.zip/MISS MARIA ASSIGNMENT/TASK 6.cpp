// Roll No: L1F26BSCS0097
// Name: Sheraz Ahmed

#include <iostream>
using namespace std;

int main() {
    int marks;

    cout << "Enter marks (0-100): ";
    cin >> marks;

    // checking grades from highest to lowest
    if (marks >= 90) {
        cout << "Grade: A" << endl;
    }
    else if (marks >= 80) {
        cout << "Grade: B" << endl;
    }
    else if (marks >= 70) {
        cout << "Grade: C" << endl;
    }
    else if (marks >= 60) {
        cout << "Grade: D" << endl;
    }
    else {
        cout << "Grade: F" << endl;
    }

    return 0;
}

/*
Observation:
We must check the highest range first because if we check lower ranges first (like >= 60),
a student with 95 marks will get a D grade instead of an A, because that condition will become true first.
*/
