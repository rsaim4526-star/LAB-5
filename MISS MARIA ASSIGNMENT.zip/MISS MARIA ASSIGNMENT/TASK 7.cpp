// Roll No: L1F26BSCS0097
// Name: Sheraz Ahmed

#include <iostream>
using namespace std;

int main() {
    int temperature;

    cout << "Enter temperature in Celsius: ";
    cin >> temperature;

    // checking temperature description
    if (temperature < 10) {
        cout << "Weather: Cold" << endl;
    }
    else if (temperature < 25) {
        cout << "Weather: Pleasant" << endl;
    }
    else if (temperature < 35) {
        cout << "Weather: Warm" << endl;
    }
    else {
        cout << "Weather: Hot" << endl;
    }

    return 0;
}

/*
Observation:
For temperature 18, the second condition (temperature < 25) becomes true first.
The first condition (18 < 10) is false, so it moves to the next one and prints Pleasant.
*/
