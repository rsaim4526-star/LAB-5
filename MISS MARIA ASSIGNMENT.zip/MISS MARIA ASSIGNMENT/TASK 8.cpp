// Roll No: L1F26BSCS0097
// Name: Sheraz Ahmed

#include <iostream>
using namespace std;

int main() {
    int marks;

    cout << "Enter marks: ";
    cin >> marks;

    // Fixed: changed '=' to '>=' for correct logical comparison
    if (marks >= 50) {
        cout << "Pass" << endl;
    }
    else {
        cout << "Fail" << endl;
    }

    return 0;
}

/*
Observation:
The single '=' is an assignment operator used to store a value in a variable.
The double '==' is a relational operator used to compare two values for equality.
*/
